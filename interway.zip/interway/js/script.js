/*
 *
 *    CUSTOM.JS
 *
 */
(function($){

  // STICKY //
    function sticky() {

      var sticky_point = $(".header").height() + 20;

          $(window).scroll(function(e){

              if ($(window).scrollTop() > sticky_point && $(window).width() > 600) {
                $("#panel").addClass("header-sticky-open");
                $(".header > div").removeClass("header-border");
              } 
              else {
                $("#panel").removeClass("header-sticky-open");
                $(".header > div").addClass("header-border");
              }
          });
    }

  $(document).ready(function(){

    // STICKY //
    if ($("header").hasClass("sticky-header")) {
      sticky();
    }

  });

  //NAVIGACIA
  $(".toggle").on("click", function() {
      if ($(".item").hasClass("active")) {
          $(".item").removeClass("active");
          $(this).find("a").html("<i class='fas fa-bars'></i>");
      } else {
          $(".item").addClass("active");
          $(this).find("a").html("<i class='fas fa-times'></i>");
      }
  });
  
})(window.jQuery);